#!/usr/bin/env python3
"""Small dual-backend runtime for NoirSonance CardputerZero apps."""

from __future__ import annotations

import argparse
import array
import json
import mmap
import os
import random
import select
import shutil
import signal
import struct
import subprocess
import sys
import time
import wave
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

W, H = 320, 170
BG = "#070707"
PANEL = "#141414"
TEXT = "#eeeeee"
MUTED = "#898989"
DIM = "#4a4a4a"
RED = "#b91c1c"
GREEN = "#42c47a"
AMBER = "#d39b33"
CYAN = "#65b7d7"


@dataclass
class Surface:
    commands: list[tuple] = field(default_factory=list)

    def rect(self, x1, y1, x2, y2, fill=None, outline=None, width=1):
        self.commands.append(("rect", x1, y1, x2, y2, fill, outline, width))

    def line(self, x1, y1, x2, y2, fill=TEXT, width=1):
        self.commands.append(("line", x1, y1, x2, y2, fill, width))

    def text(self, x, y, value, fill=TEXT, size=10, bold=False, width=None, anchor="nw"):
        self.commands.append(("text", x, y, str(value), fill, size, bold, width, anchor))


def wrap_text(value: str, columns: int) -> list[str]:
    lines: list[str] = []
    for source in value.splitlines() or [""]:
        while len(source) > columns:
            split = source.rfind(" ", 0, columns + 1)
            if split < 1:
                split = columns
            lines.append(source[:split])
            source = source[split:].lstrip()
        lines.append(source)
    return lines


class AmbientLoop:
    """Best-effort generated ambience for Windows simulation and ALSA devices."""

    def __init__(self, data_dir: Path):
        self.data_dir = data_dir
        self.process = None

    def _ensure_wave(self, kind: str):
        path = self.data_dir / f"{kind}.wav"
        if path.exists():
            return path
        rate, seconds = 22050, 2
        rng = random.Random(42 if kind == "static" else 84)
        samples = array.array("h")
        filtered = 0.0
        for _ in range(rate * seconds):
            noise = rng.uniform(-1.0, 1.0)
            if kind == "rain":
                filtered = filtered * 0.94 + noise * 0.06
                value = filtered * 12000
            else:
                value = noise * 7000
            samples.append(int(max(-32767, min(32767, value))))
        with wave.open(str(path), "wb") as out:
            out.setnchannels(1)
            out.setsampwidth(2)
            out.setframerate(rate)
            out.writeframes(samples.tobytes())
        return path

    def play(self, kind: str):
        self.stop()
        if kind == "silence":
            return
        path = self._ensure_wave(kind)
        if sys.platform == "win32":
            import winsound
            winsound.PlaySound(str(path), winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_LOOP)
        elif shutil.which("aplay"):
            self.process = subprocess.Popen(
                ["aplay", "--quiet", "--loop=0", str(path)],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )

    def stop(self):
        if sys.platform == "win32":
            try:
                import winsound
                winsound.PlaySound(None, 0)
            except RuntimeError:
                pass
        if self.process and self.process.poll() is None:
            self.process.terminate()
        self.process = None


class BaseApp:
    app_id = "noirsonance"
    title = "NoirSonance"

    def __init__(self):
        self.quit = False
        self.notice = ""
        self.notice_until = 0.0
        default_root = Path.home() / ".local" / "share" / "noirsonance-cardputerzero"
        self.data_dir = Path(os.environ.get("NOIRSONANCE_DATA_DIR", default_root)) / self.app_id
        self.data_dir.mkdir(parents=True, exist_ok=True)

    def set_notice(self, text: str, seconds: float = 2.0):
        self.notice = text
        self.notice_until = time.monotonic() + seconds

    def tick(self, now: float):
        if self.notice and now >= self.notice_until:
            self.notice = ""

    def handle_key(self, key: str, char: str = "", pressed: bool = True):
        if pressed and key in ("q", "escape"):
            self.quit = True

    def on_exit(self):
        pass

    def render(self) -> Surface:
        surface = Surface()
        self.shell(surface)
        return surface

    def shell(self, surface: Surface, section: str = ""):
        surface.rect(0, 0, W - 1, H - 1, fill=BG, outline=DIM)
        surface.text(7, 4, "Noir", TEXT, 11, True)
        surface.text(30, 4, "Sonance", RED, 11, True)
        surface.text(W - 7, 5, section, MUTED, 8, anchor="ne")
        surface.line(6, 19, W - 7, 19, DIM)
        if self.notice:
            surface.rect(5, H - 18, W - 6, H - 5, fill=PANEL, outline=RED)
            surface.text(9, H - 16, self.notice[:52], TEXT, 9)

    def load_json(self, name: str, default: Any):
        path = self.data_dir / name
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return default

    def save_json(self, name: str, value: Any):
        path = self.data_dir / name
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(json.dumps(value, indent=2), encoding="utf-8")
        tmp.replace(path)


class TkBackend:
    SKIN_W = 1280
    SKIN_H = 840
    LCD_X = 323
    LCD_Y = 60
    LCD_W = 639
    LCD_H = 339
    KEY_W = 78
    KEY_H = 54
    KEY_MAP = [
        (84, 385, "escape", ""), (1201, 385, "tab", ""),
        (84, 482, "1", "1"), (195, 482, "2", "2"), (307, 482, "3", "3"),
        (419, 482, "4", "4"), (531, 482, "5", "5"), (642, 482, "6", "6"),
        (754, 482, "7", "7"), (866, 482, "8", "8"), (978, 482, "9", "9"),
        (1089, 482, "0", "0"), (1201, 482, "backspace", ""),
        (84, 579, "tab", ""), (195, 579, "q", "q"), (307, 579, "w", "w"),
        (419, 579, "e", "e"), (531, 579, "r", "r"), (642, 579, "t", "t"),
        (754, 579, "y", "y"), (866, 579, "u", "u"), (978, 579, "i", "i"),
        (1089, 579, "o", "o"), (1201, 579, "p", "p"),
        (84, 675, "shift", ""), (195, 675, "a", "a"), (307, 675, "s", "s"),
        (419, 675, "d", "d"), (531, 675, "f", "f"), (642, 675, "g", "g"),
        (754, 675, "h", "h"), (866, 675, "j", "j"), (978, 675, "up", ""),
        (1089, 675, "down", ""), (1201, 675, "enter", ""),
        (84, 772, "fn", ""), (195, 772, "ctrl", ""), (307, 772, "alt", ""),
        (419, 772, "left", ""), (531, 772, "down", ""), (642, 772, "right", ""),
        (754, 772, "v", "v"), (866, 772, "b", "b"), (978, 772, "n", "n"),
        (1089, 772, "m", "m"), (1201, 772, "space", " "),
    ]

    def __init__(self, app: BaseApp, scale: int = 3):
        import tkinter as tk

        self.tk = tk
        self.app = app
        self.skin_path = Path(os.environ.get("NOIRSONANCE_SKIN_PATH", ""))
        self.skinned = self.skin_path.is_file()
        self.scale = 0.5 if self.skinned else scale
        self.root = tk.Tk()
        self.root.title(f"{app.title} - CardputerZero Simulator")
        if self.skinned:
            canvas_w = int(self.SKIN_W * self.scale)
            canvas_h = int(self.SKIN_H * self.scale)
            self.skin_source = tk.PhotoImage(file=str(self.skin_path))
            self.skin_image = self.skin_source.subsample(2, 2)
        else:
            canvas_w = W * scale
            canvas_h = H * scale
            self.skin_source = None
            self.skin_image = None
        self.canvas = tk.Canvas(self.root, width=canvas_w, height=canvas_h, bg=BG, highlightthickness=0)
        self.canvas.pack()
        self.root.resizable(False, False)
        self.root.bind_all("<KeyPress>", self._key_down)
        self.root.bind_all("<KeyRelease>", self._key_up)
        self.root.bind("<FocusIn>", lambda _event: self.canvas.focus_set())
        self.canvas.bind("<Button-1>", self._mouse_down)
        self.canvas.bind("<ButtonRelease-1>", self._mouse_up)
        self.root.after(150, self._claim_focus)
        self.root.protocol("WM_DELETE_WINDOW", self._close)
        self.pressed_mouse_key = None

    def _claim_focus(self):
        try:
            self.root.lift()
            self.root.focus_force()
            self.canvas.focus_set()
        except self.tk.TclError:
            pass

    def _close(self):
        self.app.quit = True

    def _normalize(self, event):
        table = {
            "Escape": "escape", "Return": "enter", "BackSpace": "backspace",
            "Delete": "delete", "Tab": "tab", "space": "space",
            "Up": "up", "Down": "down", "Left": "left", "Right": "right",
        }
        return table.get(event.keysym, event.keysym.lower()), event.char or ""

    def _key_down(self, event):
        key, char = self._normalize(event)
        self.app.handle_key(key, char, True)

    def _key_up(self, event):
        key, char = self._normalize(event)
        self.app.handle_key(key, char, False)

    def _mouse_to_key(self, x: int, y: int):
        if not self.skinned:
            return None
        sx = x / self.scale
        sy = y / self.scale
        half_w = self.KEY_W / 2
        half_h = self.KEY_H / 2
        for cx, cy, key, char in self.KEY_MAP:
            if cx - half_w <= sx <= cx + half_w and cy - half_h <= sy <= cy + half_h:
                return key, char
        return None

    def _mouse_down(self, event):
        self._claim_focus()
        mapped = self._mouse_to_key(event.x, event.y)
        if mapped:
            key, char = mapped
            self.pressed_mouse_key = mapped
            self.app.handle_key(key, char, True)

    def _mouse_up(self, _event):
        if self.pressed_mouse_key:
            key, char = self.pressed_mouse_key
            self.app.handle_key(key, char, False)
            self.pressed_mouse_key = None

    def _point(self, x: int, y: int):
        if self.skinned:
            return (
                (self.LCD_X + x * self.LCD_W / W) * self.scale,
                (self.LCD_Y + y * self.LCD_H / H) * self.scale,
            )
        return x * self.scale, y * self.scale

    def _width(self, width: int):
        if self.skinned:
            return max(1, int(width * self.LCD_W / W * self.scale))
        return max(1, int(width * self.scale))

    def _font_size(self, size: int):
        if self.skinned:
            return max(6, int(size * self.LCD_H / H * self.scale))
        return max(6, int(size * self.scale))

    def render(self, surface: Surface):
        c = self.canvas
        c.delete("all")
        for cmd in surface.commands:
            if cmd[0] == "rect":
                _, x1, y1, x2, y2, fill, outline, width = cmd
                px1, py1 = self._point(x1, y1)
                px2, py2 = self._point(x2, y2)
                c.create_rectangle(px1, py1, px2, py2, fill=fill or "", outline=outline or "", width=self._width(width))
            elif cmd[0] == "line":
                _, x1, y1, x2, y2, fill, width = cmd
                px1, py1 = self._point(x1, y1)
                px2, py2 = self._point(x2, y2)
                c.create_line(px1, py1, px2, py2, fill=fill, width=self._width(width))
            elif cmd[0] == "text":
                _, x, y, text, fill, size, bold, width, anchor = cmd
                px, py = self._point(x, y)
                text_width = self._point(width, 0)[0] - self._point(0, 0)[0] if width else None
                c.create_text(px, py, text=text, fill=fill, anchor=anchor,
                              width=text_width,
                              font=("Consolas", self._font_size(size), "bold" if bold else "normal"))
        if self.skinned:
            c.create_image(0, 0, image=self.skin_image, anchor="nw")

    def run(self):
        def loop():
            self.app.tick(time.monotonic())
            self.render(self.app.render())
            if self.app.quit:
                self.root.destroy()
                return
            self.root.after(50, loop)
        loop()
        try:
            self.root.mainloop()
        finally:
            self.app.on_exit()


class FramebufferBackend:
    FBIOGET_VSCREENINFO = 0x4600
    FBIOGET_FSCREENINFO = 0x4602

    def __init__(self, app: BaseApp):
        import fcntl
        from PIL import Image, ImageDraw, ImageFont

        self.fcntl = fcntl
        self.Image, self.ImageDraw, self.ImageFont = Image, ImageDraw, ImageFont
        self.app = app
        self.fb_path = os.environ.get("APPLAUNCH_LINUX_FBDEV_DEVICE", "/dev/fb0")
        self.fd = os.open(self.fb_path, os.O_RDWR)
        var = bytearray(160)
        self.fcntl.ioctl(self.fd, self.FBIOGET_VSCREENINFO, var)
        self.w, self.h, _, _, _, _, bpp, _ = struct.unpack_from("8I", var, 0)
        if bpp != 16:
            raise RuntimeError(f"Expected RGB565 framebuffer, got {bpp} bpp")
        fix_fmt = "16sL" + "I" * 6 + "HHHI"
        fix = bytearray(struct.calcsize(fix_fmt))
        self.fcntl.ioctl(self.fd, self.FBIOGET_FSCREENINFO, fix)
        values = struct.unpack(fix_fmt, fix)
        self.smem_len, self.line_length = values[2], values[8]
        self.mm = mmap.mmap(self.fd, self.smem_len, mmap.MAP_SHARED, mmap.PROT_READ | mmap.PROT_WRITE)
        self.fonts: dict[tuple[int, bool], Any] = {}
        self.inputs = self._open_inputs()

    def _font(self, size, bold):
        key = (size, bold)
        if key not in self.fonts:
            path = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"
            try:
                self.fonts[key] = self.ImageFont.truetype(path, size)
            except OSError:
                self.fonts[key] = self.ImageFont.load_default()
        return self.fonts[key]

    def _open_inputs(self):
        try:
            from evdev import InputDevice, ecodes, list_devices
        except ImportError:
            return []
        self.ecodes = ecodes
        inputs = []
        for path in list_devices():
            try:
                dev = InputDevice(path)
                caps = dev.capabilities().get(ecodes.EV_KEY, [])
                if ecodes.KEY_ESC in caps or ecodes.KEY_ENTER in caps:
                    inputs.append(dev)
                else:
                    dev.close()
            except OSError:
                pass
        return inputs

    def _poll_keys(self):
        if not self.inputs:
            return
        readable, _, _ = select.select([d.fd for d in self.inputs], [], [], 0)
        ec = self.ecodes
        names = {
            ec.KEY_ESC: "escape", ec.KEY_ENTER: "enter", ec.KEY_BACKSPACE: "backspace",
            ec.KEY_DELETE: "delete", ec.KEY_TAB: "tab", ec.KEY_SPACE: "space",
            ec.KEY_UP: "up", ec.KEY_DOWN: "down", ec.KEY_LEFT: "left", ec.KEY_RIGHT: "right",
        }
        for dev in self.inputs:
            if dev.fd not in readable:
                continue
            for event in dev.read():
                if event.type != ec.EV_KEY:
                    continue
                pressed = event.value != 0
                key = names.get(event.code)
                if key is None:
                    label = ec.KEY.get(event.code, "")
                    if label.startswith("KEY_") and len(label) == 5:
                        key = label[-1].lower()
                    elif label.startswith("KEY_") and label[4:].isdigit():
                        key = label[4:]
                if key:
                    char = " " if key == "space" else key if len(key) == 1 else ""
                    self.app.handle_key(key, char, pressed)

    def render(self, surface: Surface):
        img = self.Image.new("RGB", (self.w, self.h), BG)
        draw = self.ImageDraw.Draw(img)
        for cmd in surface.commands:
            if cmd[0] == "rect":
                _, x1, y1, x2, y2, fill, outline, width = cmd
                draw.rectangle((x1, y1, x2, y2), fill=fill, outline=outline, width=width)
            elif cmd[0] == "line":
                _, x1, y1, x2, y2, fill, width = cmd
                draw.line((x1, y1, x2, y2), fill=fill, width=width)
            elif cmd[0] == "text":
                _, x, y, text, fill, size, bold, width, anchor = cmd
                font = self._font(size, bold)
                try:
                    bbox = draw.textbbox((0, 0), text, font=font)
                    text_w = bbox[2] - bbox[0]
                    text_h = bbox[3] - bbox[1]
                except Exception:
                    text_w = len(str(text)) * max(6, size // 2)
                    text_h = max(8, size)
                tx, ty = x, y
                anchor = anchor or "nw"
                if "e" in anchor:
                    tx -= text_w
                elif anchor in ("n", "s", "m", "mm") or "m" in anchor:
                    tx -= text_w // 2
                if "s" in anchor:
                    ty -= text_h
                elif anchor in ("w", "e", "m", "lm", "mm", "rm") or "m" in anchor:
                    ty -= text_h // 2
                draw.text((tx, ty), text, fill=fill, font=font)
        pixels = img.load()
        rows = []
        for y in range(self.h):
            row = bytearray()
            for x in range(self.w):
                r, g, b = pixels[x, y]
                value = ((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3)
                row.extend((value & 0xff, value >> 8))
            rows.append(row)
        for y, row in enumerate(rows):
            self.mm.seek(y * self.line_length)
            self.mm.write(row)

    def run(self):
        running = True
        def stop(_signum, _frame):
            nonlocal running
            running = False
        signal.signal(signal.SIGINT, stop)
        signal.signal(signal.SIGTERM, stop)
        try:
            while running and not self.app.quit:
                self._poll_keys()
                self.app.tick(time.monotonic())
                self.render(self.app.render())
                time.sleep(0.05)
        finally:
            self.app.on_exit()
            self.mm.close()
            os.close(self.fd)
            for dev in self.inputs:
                dev.close()


def run_app(app_type):
    parser = argparse.ArgumentParser()
    parser.add_argument("--desktop", action="store_true", help="force Tk desktop simulator")
    parser.add_argument("--headless-smoke", action="store_true", help="render one frame and exit")
    args = parser.parse_args()
    app = app_type()
    if args.headless_smoke:
        frame = app.render()
        if not frame.commands:
            raise RuntimeError("app rendered an empty frame")
        print(f"{app.app_id}: smoke ok ({len(frame.commands)} draw commands)")
        return 0
    if args.desktop or not sys.platform.startswith("linux") or not os.path.exists("/dev/fb0"):
        TkBackend(app).run()
    else:
        FramebufferBackend(app).run()
    return 0
