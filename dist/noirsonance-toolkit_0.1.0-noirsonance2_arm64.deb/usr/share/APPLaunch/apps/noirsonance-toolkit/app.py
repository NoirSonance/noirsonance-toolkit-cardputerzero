#!/usr/bin/env python3
"""NoirSonance Toolkit handheld adaptation."""

from __future__ import annotations

import math
import random
import sys
import time
import wave
from dataclasses import dataclass
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(HERE), str(HERE.parent / "_shared")]
from noir_runtime import AMBER, CYAN, DIM, GREEN, MUTED, PANEL, RED, TEXT, BaseApp, Surface, run_app, wrap_text


NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
MAJOR_KEYS = ["C", "G", "D", "A", "E", "B", "F#", "Db", "Ab", "Eb", "Bb", "F"]
MAJOR_SCALE = [0, 2, 4, 5, 7, 9, 11]
NAT_MINOR = [0, 2, 3, 5, 7, 8, 10]
MODES = [
    ("IONIAN", "1 2 3 4 5 6 7"),
    ("DORIAN", "1 2 b3 4 5 6 b7"),
    ("PHRYGIAN", "1 b2 b3 4 5 b6 b7"),
    ("LYDIAN", "1 2 3 #4 5 6 7"),
    ("MIXOLYDIAN", "1 2 3 4 5 6 b7"),
    ("AEOLIAN", "1 2 b3 4 5 b6 b7"),
    ("LOCRIAN", "1 b2 b3 4 b5 b6 b7"),
]


@dataclass
class Tool:
    id: str
    name: str
    category: str
    desc: str
    value: float = 0.0
    step: float = 1.0
    minimum: float | None = None
    maximum: float | None = None


def clamp(value: float, minimum: float | None, maximum: float | None) -> float:
    if minimum is not None:
        value = max(minimum, value)
    if maximum is not None:
        value = min(maximum, value)
    return value


def midi_to_freq(midi: float, a4: float = 440.0) -> float:
    return a4 * (2 ** ((midi - 69.0) / 12.0))


def freq_to_midi(freq: float, a4: float = 440.0) -> float:
    return 69.0 + 12.0 * math.log2(max(freq, 0.001) / a4)


def note_for_freq(freq: float) -> tuple[str, float, int]:
    midi = freq_to_midi(freq)
    rounded = int(round(midi))
    note = f"{NOTE_NAMES[rounded % 12]}{rounded // 12 - 1}"
    cents = int(round((midi - rounded) * 100))
    return note, midi, cents


def db_to_linear(db: float) -> float:
    return 10 ** (db / 20.0)


def linear_to_db(linear: float) -> float:
    return -120.0 if linear <= 0 else 20.0 * math.log10(linear)


def fmt_hz(freq: float) -> str:
    if freq >= 1000:
        return f"{freq / 1000:.2f} kHz"
    return f"{freq:.2f} Hz"


def fmt_ms(ms: float) -> str:
    if ms >= 1000:
        return f"{ms / 1000:.2f} s"
    return f"{ms:.2f} ms"


def note_from(root: str, offset: int) -> str:
    base = NOTE_NAMES.index(root.replace("Db", "C#").replace("Eb", "D#").replace("Ab", "G#").replace("Bb", "A#"))
    return NOTE_NAMES[(base + offset) % 12]


class NoirToolkit(BaseApp):
    app_id = "noirsonance-toolkit"
    title = "NoirSonance Toolkit"
    categories = [
        ("frequency", "Frequency & Audio"),
        ("tempo", "Tempo & Time"),
        ("theory", "Music Theory"),
        ("analysis", "Analysis"),
        ("guides", "Guides & References"),
        ("utilities", "Utilities"),
    ]

    def __init__(self):
        super().__init__()
        self.mode = "categories"
        self.category_index = 0
        self.list_page = 0
        self.tool_index = 0
        self.field = 0
        self.taps: list[float] = []
        self.bpm = 120.0
        self.loaded_audio: dict[str, object] = {}
        self.audio_pick_index = 0
        self.tools = self.make_tools()
        self.melody = self.generate_melody("C")

    def make_tools(self) -> list[Tool]:
        return [
            Tool("fletcher-munson", "Fletcher-Munson", "frequency", "Equal-loudness contour reference", 80, 10, 20, 100),
            Tool("midi-freq", "MIDI/Freq Converter", "frequency", "MIDI note to frequency", 69, 1, 0, 127),
            Tool("eq-chart", "EQ Chart", "frequency", "Mixing frequency range map"),
            Tool("voice-eq", "Voice EQ Reference", "frequency", "Vocal EQ problem/target zones"),
            Tool("audio-freq-calc", "Audio Freq Calculator", "frequency", "Harmonics, wavelength, period", 440, 10, 20, 20000),
            Tool("sample-rate", "Sample Rate Calculator", "frequency", "Nyquist and samples per time", 48000, 1000, 8000, 384000),
            Tool("bit-depth", "Bit Depth Calculator", "frequency", "Dynamic range and noise floor", 24, 1, 8, 32),
            Tool("latency", "Latency Calculator", "frequency", "Buffer latency at sample rate", 256, 32, 16, 4096),
            Tool("file-size", "File Size Calculator", "frequency", "PCM file size estimate", 180, 30, 1, 7200),
            Tool("phase-correlation", "Phase Correlation", "frequency", "Stereo phase interpretation", 0.5, 0.1, -1, 1),
            Tool("guitar-tuner", "Guitar Tuner", "frequency", "Standard guitar string notes", 0, 1, 0, 5),
            Tool("virtual-piano", "Virtual Piano", "frequency", "Keyboard note reference", 60, 1, 21, 108),
            Tool("drum-pads", "Drum Pads", "frequency", "Drum pad key map"),
            Tool("spectrum-analyzer", "Spectrum Analyzer", "frequency", "Frequency band reference"),
            Tool("tone-generator", "Tone Generator", "frequency", "Tone setup reference", 440, 10, 20, 20000),
            Tool("db-linear", "dB/Linear Converter", "frequency", "dB to linear amplitude", 0, 1, -80, 24),
            Tool("tap-tempo", "Tap Tempo", "tempo", "Tap to detect BPM", 120, 0, 20, 300),
            Tool("lfo-rate", "LFO Rate Calculator", "tempo", "BPM synced modulation rates", 120, 1, 20, 300),
            Tool("reverb-time", "Reverb Time Calculator", "tempo", "Pre-delay and decay suggestions", 120, 1, 20, 300),
            Tool("delay-calc", "Delay Calculator", "tempo", "Synced delay times", 120, 1, 20, 300),
            Tool("metronome", "Metronome", "tempo", "Click interval and accents", 120, 1, 20, 300),
            Tool("chord-progression", "Chord Progression Builder", "theory", "Common progressions by key", 0, 1, 0, 11),
            Tool("scale-mode", "Scale/Mode Reference", "theory", "Modes and interval patterns", 0, 1, 0, len(MODES) - 1),
            Tool("melody-generator", "Melody Generator", "theory", "Random major-scale melody", 0, 1, 0, 11),
            Tool("circle-of-fifths", "Circle of Fifths", "theory", "Key relationships", 0, 1, 0, 11),
            Tool("chord-finder", "Chord Finder", "theory", "Triad quality reference", 0, 1, 0, 11),
            Tool("lufs-meter", "LUFS Meter", "analysis", "Loudness targets reference", -14, 1, -30, 0),
            Tool("stereo-width", "Stereo Width Meter", "analysis", "Width and balance reference", 100, 10, 0, 200),
            Tool("mastering-guide", "Mastering Guide", "guides", "Compact mastering workflow"),
            Tool("gain-staging", "Gain Staging Checklist", "guides", "Headroom and level checklist"),
            Tool("eq-moves", "EQ Move Library", "guides", "Common EQ moves"),
            Tool("note-length", "Note Length Calculator", "utilities", "Note durations at BPM", 120, 1, 20, 300),
            Tool("pitch-shift", "Pitch Shift/Cents", "utilities", "Semitones, cents, ratio", 0, 1, -24, 24),
            Tool("bpm-from-length", "BPM from Length", "utilities", "Loop length to BPM", 2.0, 0.1, 0.1, 32),
            Tool("freq-to-note", "Freq to Note", "utilities", "Nearest note and cents", 440, 1, 1, 20000),
        ]

    def category_tools(self) -> list[Tool]:
        cat = self.categories[self.category_index][0]
        return [tool for tool in self.tools if tool.category == cat]

    def current_tool(self) -> Tool:
        tools = self.category_tools()
        self.tool_index = min(self.tool_index, len(tools) - 1)
        return tools[self.tool_index]

    def select_category(self, index: int):
        if 0 <= index < len(self.categories):
            self.category_index = index
            self.list_page = 0
            self.tool_index = 0
            self.mode = "list"

    def select_from_page(self, slot: int):
        idx = self.list_page * 5 + slot
        if idx < len(self.category_tools()):
            self.tool_index = idx
            self.field = 0
            self.taps = []
            self.mode = "tool"

    def adjust(self, delta: int):
        tool = self.current_tool()
        tool.value = clamp(tool.value + delta * tool.step, tool.minimum, tool.maximum)
        if tool.id == "melody-generator":
            self.melody = self.generate_melody(MAJOR_KEYS[int(round(tool.value)) % 12])

    def tap(self):
        now = time.monotonic()
        self.taps = [x for x in self.taps if now - x < 4.0]
        self.taps.append(now)
        if len(self.taps) > 1:
            intervals = [b - a for a, b in zip(self.taps, self.taps[1:])]
            self.bpm = 60.0 / (sum(intervals) / len(intervals))
            self.current_tool().value = self.bpm

    def generate_melody(self, root: str) -> str:
        return " ".join(note_from(root, random.choice(MAJOR_SCALE)) for _ in range(8))

    def current_audio(self) -> dict[str, object]:
        return self.loaded_audio.get(self.current_tool().id, {}) if isinstance(self.loaded_audio, dict) else {}

    def load_audio_file(self):
        tool = self.current_tool()
        if tool.id not in {"lufs-meter", "stereo-width", "phase-correlation", "spectrum-analyzer", "file-size"}:
            return
        path = ""
        try:
            from tkinter import filedialog
            path = filedialog.askopenfilename(
                title=f"Load audio for {tool.name}",
                filetypes=[("WAV audio", "*.wav"), ("All files", "*.*")],
            )
        except Exception:
            path = ""
        if not path:
            path = self.next_audio_candidate()
        if not path:
            self.set_notice("No WAV found. Put one in Music/Downloads.", 4)
            return
        try:
            info = self.analyze_wav(Path(path))
        except Exception as exc:
            self.set_notice(f"Could not load WAV: {exc}", 4)
            return
        self.loaded_audio[tool.id] = info
        if tool.id == "file-size":
            tool.value = max(1, float(info["duration"]))
        elif tool.id == "lufs-meter":
            tool.value = float(info["rms_db"])
        elif tool.id == "stereo-width":
            tool.value = float(info["width"])
        elif tool.id == "phase-correlation":
            tool.value = float(info["correlation"])
        elif tool.id == "spectrum-analyzer":
            tool.value = float(info["peak_freq"])
        self.set_notice(f"Loaded {info['name']}", 2)

    def next_audio_candidate(self) -> str:
        roots = [
            self.data_dir,
            Path.home() / "Music",
            Path.home() / "Downloads",
            Path.home() / "Desktop",
            Path.cwd(),
        ]
        files: list[Path] = []
        for root in roots:
            if root.exists():
                files.extend(sorted(root.glob("*.wav")))
                files.extend(sorted(root.glob("*.WAV")))
        unique = []
        seen = set()
        for path in files:
            resolved = str(path.resolve())
            if resolved not in seen:
                seen.add(resolved)
                unique.append(path)
        if not unique:
            return ""
        path = unique[self.audio_pick_index % len(unique)]
        self.audio_pick_index += 1
        return str(path)

    def analyze_wav(self, path: Path) -> dict[str, object]:
        with wave.open(str(path), "rb") as wav:
            channels = wav.getnchannels()
            sample_rate = wav.getframerate()
            sample_width = wav.getsampwidth()
            frames = wav.getnframes()
            max_frames = min(frames, sample_rate * 90)
            raw = wav.readframes(max_frames)
        if channels < 1:
            raise ValueError("no channels")
        if sample_width not in (1, 2, 3, 4):
            raise ValueError(f"{sample_width * 8}-bit PCM unsupported")

        def sample_at(offset: int) -> float:
            chunk = raw[offset : offset + sample_width]
            if sample_width == 1:
                return (chunk[0] - 128) / 128.0
            signed = int.from_bytes(chunk, "little", signed=True)
            return signed / float(2 ** (sample_width * 8 - 1))

        left: list[float] = []
        right: list[float] = []
        frame_size = channels * sample_width
        stride = max(1, max_frames // 20000)
        for frame in range(0, max_frames, stride):
            base = frame * frame_size
            if base + frame_size > len(raw):
                break
            l = sample_at(base)
            r = sample_at(base + sample_width) if channels > 1 else l
            left.append(l)
            right.append(r)
        if not left:
            raise ValueError("empty audio")

        mono = [(l + r) / 2 for l, r in zip(left, right)]
        rms = math.sqrt(sum(s * s for s in mono) / len(mono))
        peak = max(abs(s) for s in mono)
        rms_db = 20 * math.log10(rms) if rms > 0 else -120.0
        peak_db = 20 * math.log10(peak) if peak > 0 else -120.0
        crest = peak_db - rms_db

        sum_lr = sum(l * r for l, r in zip(left, right))
        sum_ll = sum(l * l for l in left)
        sum_rr = sum(r * r for r in right)
        correlation = sum_lr / math.sqrt(sum_ll * sum_rr) if sum_ll and sum_rr else 0.0
        mid = [(l + r) / 2 for l, r in zip(left, right)]
        side = [(l - r) / 2 for l, r in zip(left, right)]
        mid_e = sum(s * s for s in mid) / len(mid)
        side_e = sum(s * s for s in side) / len(side)
        width = (side_e / (mid_e + side_e) * 200.0) if (mid_e + side_e) > 0 else 0.0

        peak_freq = self.estimate_peak_freq(mono, sample_rate)
        return {
            "name": path.name,
            "path": str(path),
            "size": path.stat().st_size,
            "duration": frames / sample_rate if sample_rate else 0,
            "channels": channels,
            "sample_rate": sample_rate,
            "bits": sample_width * 8,
            "rms_db": rms_db,
            "peak_db": peak_db,
            "crest": crest,
            "correlation": correlation,
            "width": width,
            "mid_db": 10 * math.log10(mid_e) if mid_e > 0 else -120.0,
            "side_db": 10 * math.log10(side_e) if side_e > 0 else -120.0,
            "peak_freq": peak_freq,
        }

    def estimate_peak_freq(self, samples: list[float], sample_rate: int) -> float:
        if not samples or sample_rate <= 0:
            return 0.0
        n = min(1024, len(samples))
        if n < 32:
            return 0.0
        start = max(0, (len(samples) - n) // 2)
        window = samples[start : start + n]
        best_k, best_mag = 0, 0.0
        for k in range(1, n // 2):
            re = 0.0
            im = 0.0
            for i, sample in enumerate(window):
                angle = 2 * math.pi * k * i / n
                re += sample * math.cos(angle)
                im -= sample * math.sin(angle)
            mag = re * re + im * im
            if mag > best_mag:
                best_k, best_mag = k, mag
        return best_k * sample_rate / n

    def handle_key(self, key, char="", pressed=True):
        if not pressed:
            return
        if self.mode == "categories":
            if key in ("q", "escape"):
                self.quit = True
            elif key == "left":
                if self.category_index % 2 == 1:
                    self.category_index -= 1
            elif key == "right":
                if self.category_index % 2 == 0 and self.category_index + 1 < len(self.categories):
                    self.category_index += 1
            elif key == "up":
                self.category_index = (self.category_index - 2) % len(self.categories)
            elif key in ("down", "tab"):
                self.category_index = (self.category_index + 2) % len(self.categories)
            elif key in ("enter", "space"):
                self.select_category(self.category_index)
            elif key in ("1", "2", "3", "4", "5", "6"):
                self.select_category(int(key) - 1)
            return
        if self.mode == "list":
            tools = self.category_tools()
            pages = max(1, math.ceil(len(tools) / 5))
            if key == "escape":
                self.mode = "categories"
            elif key == "up":
                self.tool_index = (self.tool_index - 1) % len(tools)
                self.list_page = self.tool_index // 5
            elif key in ("down", "tab"):
                self.tool_index = (self.tool_index + 1) % len(tools)
                self.list_page = self.tool_index // 5
            elif key == "left":
                self.list_page = (self.list_page - 1) % pages
                self.tool_index = min(self.list_page * 5, len(tools) - 1)
            elif key == "right":
                self.list_page = (self.list_page + 1) % pages
                self.tool_index = min(self.list_page * 5, len(tools) - 1)
            elif key in ("enter", "space"):
                self.mode = "tool"
            elif key in ("1", "2", "3", "4", "5"):
                self.select_from_page(int(key) - 1)
            return
        if key == "escape":
            self.mode = "list"
        elif key in ("left", "down"):
            self.adjust(-1)
        elif key in ("right", "up"):
            self.adjust(1)
        elif key == "l":
            self.load_audio_file()
        elif key == "space":
            if self.current_tool().id == "tap-tempo":
                self.tap()
            elif self.current_tool().id == "melody-generator":
                self.melody = self.generate_melody(MAJOR_KEYS[int(round(self.current_tool().value)) % 12])

    def tool_lines(self, tool: Tool) -> list[str]:
        v = tool.value
        if tool.id == "fletcher-munson":
            return [f"PHON {v:.0f}", "Low volume: lows/highs feel softer", "Mix check: 75-85 phon", "Beware bright boosts when loud"]
        if tool.id == "midi-freq":
            midi = int(round(v))
            return [f"MIDI       {midi}", f"NOTE       {NOTE_NAMES[midi % 12]}{midi // 12 - 1}", f"FREQUENCY  {fmt_hz(midi_to_freq(midi))}"]
        if tool.id == "eq-chart":
            return ["20-60 sub weight", "60-250 body / mud", "250-2k tone / box", "2k-6k presence", "6k-20k air / hiss"]
        if tool.id == "voice-eq":
            return ["HPF 70-120 Hz", "Mud 180-350 Hz", "Nasal 800-1.5k", "Presence 3-5 kHz", "Air 10-16 kHz"]
        if tool.id == "audio-freq-calc":
            return [f"FREQ       {fmt_hz(v)}", f"PERIOD     {1000 / v:.3f} ms", f"WAVELEN    {343 / v:.3f} m", f"2ND HARM   {fmt_hz(v * 2)}", f"3RD HARM   {fmt_hz(v * 3)}"]
        if tool.id == "sample-rate":
            return [f"SAMPLE RATE {v:.0f} Hz", f"NYQUIST     {fmt_hz(v / 2)}", f"1 ms        {v / 1000:.1f} samples", f"10 ms       {v / 100:.0f} samples"]
        if tool.id == "bit-depth":
            return [f"BIT DEPTH  {v:.0f}", f"DYN RANGE  {v * 6.02:.1f} dB", f"NOISE FLR  {-v * 6.02:.1f} dBFS", "24-bit = safe tracking headroom"]
        if tool.id == "latency":
            sample_rate = 48000
            one_way = v / sample_rate * 1000
            return [f"BUFFER     {v:.0f} samples", f"ONE WAY    {one_way:.2f} ms @48k", f"ROUNDTRIP  {one_way * 2:.2f} ms", f"64/128 live, 256+ mix"]
        if tool.id == "file-size":
            audio = self.current_audio()
            if audio:
                mb = float(audio["size"]) / 1024 / 1024
                return [f"FILE {str(audio['name'])[:24]}", f"SIZE       {mb:.2f} MB", f"DURATION   {float(audio['duration']):.2f} sec", f"FORMAT     {audio['sample_rate']}Hz/{audio['bits']}b/{audio['channels']}ch"]
            mb = v * 48000 * 24 * 2 / 8 / 1024 / 1024
            return [f"DURATION   {v:.0f} sec", "FORMAT     48k/24 stereo WAV", f"SIZE       {mb:.1f} MB", f"10 TAKES   {mb * 10:.1f} MB"]
        if tool.id == "phase-correlation":
            audio = self.current_audio()
            if audio:
                corr = float(audio["correlation"])
                label = "mono-safe" if corr > 0.3 else "wide/risky" if corr >= 0 else "phase cancel"
                return [f"FILE {str(audio['name'])[:24]}", f"CORR       {corr:+.3f}", f"READING    {label}", "L load another WAV"]
            label = "mono-safe" if v > 0.3 else "wide/risky" if v >= 0 else "phase cancel"
            return [f"CORRELATION {v:+.1f}", f"READING     {label}", "+1 mono, 0 wide, -1 cancel", "Check low end in mono"]
        if tool.id == "guitar-tuner":
            strings = [("E2", 82.41), ("A2", 110.0), ("D3", 146.83), ("G3", 196.0), ("B3", 246.94), ("E4", 329.63)]
            note, freq = strings[int(round(v)) % len(strings)]
            return [f"STRING     {int(v) + 1}", f"NOTE       {note}", f"FREQ       {freq:.2f} Hz", "Standard tuning: E A D G B E"]
        if tool.id == "virtual-piano":
            midi = int(round(v))
            return [f"KEY MIDI   {midi}", f"NOTE       {NOTE_NAMES[midi % 12]}{midi // 12 - 1}", f"FREQ       {fmt_hz(midi_to_freq(midi))}", "Use arrows to scan keys"]
        if tool.id == "drum-pads":
            return ["1 Kick   2 Snare", "3 Hat    4 Clap", "5 Tom    6 Ride", "Tiny map for beat sketches"]
        if tool.id == "spectrum-analyzer":
            audio = self.current_audio()
            if audio:
                return [f"FILE {str(audio['name'])[:24]}", f"PEAK       {fmt_hz(float(audio['peak_freq']))}", f"FORMAT     {audio['sample_rate']} Hz", "L load another WAV"]
            return ["Sub 20-60 / Bass 60-250", "Low mid 250-500", "Mid 500-2k / Pres 2-6k", "Air 6k-20k", "Live FFT needs audio input"]
        if tool.id == "tone-generator":
            note, _, cents = note_for_freq(v)
            return [f"TONE       {fmt_hz(v)}", f"NEAREST    {note} {cents:+d}c", "Sine: tuning / Square: buzz", "Saw: synth / Noise: test"]
        if tool.id == "db-linear":
            return [f"DECIBELS   {v:+.1f} dB", f"AMPLITUDE  {db_to_linear(v):.6f}", f"POWER      {10 ** (v / 10):.6f}", "formula amp = 10^(dB/20)"]
        if tool.id == "tap-tempo":
            return [f"TAPS       {len(self.taps)}", f"TEMPO      {tool.value:.2f} BPM", f"1/4        {60000 / max(tool.value, 1):.2f} ms", "SPACE taps the beat"]
        if tool.id == "lfo-rate":
            q = 60000 / v
            return [f"BPM        {v:.1f}", f"1/4 LFO    {1000 / q:.3f} Hz", f"1/8 LFO    {1000 / (q / 2):.3f} Hz", f"1 bar      {1000 / (q * 4):.3f} Hz"]
        if tool.id == "reverb-time":
            q = 60000 / v
            return [f"BPM        {v:.1f}", f"PREDELAY   {q / 16:.1f} ms", f"SHORT DEC  {q * 2 / 1000:.2f} s", f"LONG DEC   {q * 4 / 1000:.2f} s"]
        if tool.id == "delay-calc":
            q = 60000 / v
            return [f"BPM        {v:.1f}", f"1/4        {q:.2f} ms", f"1/8        {q / 2:.2f} ms", f"1/16       {q / 4:.2f} ms", f"1/8 dot    {q * .75:.2f} ms"]
        if tool.id == "metronome":
            return [f"TEMPO      {v:.1f} BPM", f"CLICK INT  {60000 / v:.2f} ms", "ACCENT     1 of 4", "Subdivision: quarter"]
        if tool.id == "chord-progression":
            key = MAJOR_KEYS[int(round(v)) % 12]
            return [f"KEY        {key} major", "I-V-vi-IV  pop resolve", "ii-V-I     jazz cadence", "i-bVI-bIII-bVII minor mood"]
        if tool.id == "scale-mode":
            mode, pattern = MODES[int(round(v)) % len(MODES)]
            return [f"MODE       {mode}", f"PATTERN    {pattern}", "Use against major parent scale", "Shift tonal center for color"]
        if tool.id == "melody-generator":
            key = MAJOR_KEYS[int(round(v)) % 12]
            return [f"KEY        {key} major", self.melody, "SPACE regenerates", "Arrows change key"]
        if tool.id == "circle-of-fifths":
            key = MAJOR_KEYS[int(round(v)) % 12]
            idx = MAJOR_KEYS.index(key)
            return [f"KEY        {key}", f"FIFTH      {MAJOR_KEYS[(idx + 1) % 12]}", f"FOURTH     {MAJOR_KEYS[(idx - 1) % 12]}", f"REL MIN    {note_from(key, 9)}m"]
        if tool.id == "chord-finder":
            root = MAJOR_KEYS[int(round(v)) % 12]
            return [f"ROOT       {root}", f"MAJOR      {root} {note_from(root, 4)} {note_from(root, 7)}", f"MINOR      {root} {note_from(root, 3)} {note_from(root, 7)}", f"DOM7       + {note_from(root, 10)}"]
        if tool.id == "lufs-meter":
            audio = self.current_audio()
            if audio:
                return [f"FILE {str(audio['name'])[:24]}", f"RMS        {float(audio['rms_db']):.1f} dBFS", f"PEAK       {float(audio['peak_db']):.1f} dBFS", f"CREST      {float(audio['crest']):.1f} dB"]
            return [f"TARGET     {v:.0f} LUFS", "Streaming  -14 LUFS", "CD loud    -9 to -7 LUFS", "Keep true peak <= -1 dBTP"]
        if tool.id == "stereo-width":
            audio = self.current_audio()
            if audio:
                return [f"FILE {str(audio['name'])[:24]}", f"WIDTH      {float(audio['width']):.1f}%", f"MID        {float(audio['mid_db']):.1f} dB", f"SIDE       {float(audio['side_db']):.1f} dB"]
            return [f"WIDTH      {v:.0f}%", "0 mono / 100 natural", "150+ super wide, check mono", "Bass usually centered"]
        if tool.id == "mastering-guide":
            return ["1 Clean mix, no clipping", "2 EQ broad tonal balance", "3 Compress gently", "4 Limit to target LUFS", "5 Check mono and references"]
        if tool.id == "gain-staging":
            return ["Track peaks around -12 dBFS", "Buses leave 6 dB headroom", "Plugins: match input/output", "Master before limiter < -6 dB"]
        if tool.id == "eq-moves":
            return ["Mud cut: 200-350 Hz", "Box cut: 500-900 Hz", "Presence: 3-5 kHz", "Air shelf: 10-16 kHz", "Harsh tame: 2.5-4 kHz"]
        if tool.id == "note-length":
            q = 60000 / v
            return [f"BPM        {v:.1f}", f"WHOLE      {q * 4:.2f} ms", f"1/4        {q:.2f} ms", f"1/8        {q / 2:.2f} ms", f"1/16       {q / 4:.2f} ms"]
        if tool.id == "pitch-shift":
            ratio = 2 ** (v / 12)
            return [f"SEMITONES  {v:+.1f}", f"CENTS      {v * 100:+.0f}", f"RATIO      {ratio:.6f}", f"PERCENT    {(ratio - 1) * 100:+.2f}%"]
        if tool.id == "bpm-from-length":
            return [f"LOOP LEN   {v:.2f} sec", f"1 BAR 4/4  {240 / v:.2f} BPM", f"2 BARS     {480 / v:.2f} BPM", f"4 BARS     {960 / v:.2f} BPM"]
        if tool.id == "freq-to-note":
            note, midi, cents = note_for_freq(v)
            return [f"INPUT      {fmt_hz(v)}", f"NEAREST    {note}", f"MIDI       {midi:.2f}", f"OFFSET     {cents:+d} cents"]
        return [tool.desc]

    def has_visual(self, tool: Tool) -> bool:
        return tool.id in {
            "fletcher-munson", "eq-chart", "voice-eq", "audio-freq-calc", "phase-correlation",
            "guitar-tuner", "virtual-piano", "drum-pads", "spectrum-analyzer", "tone-generator",
            "db-linear", "tap-tempo", "lfo-rate", "delay-calc", "metronome", "circle-of-fifths",
            "lufs-meter", "stereo-width", "pitch-shift", "freq-to-note",
        }

    def render_bar(self, s: Surface, x: int, y: int, w: int, h: int, ratio: float, label: str = ""):
        ratio = max(0.0, min(1.0, ratio))
        s.rect(x, y, x + w, y + h, outline=DIM)
        s.rect(x + 1, y + 1, x + int(w * ratio), y + h - 1, fill=RED if ratio > 0.72 else GREEN)
        if label:
            s.text(x + w + 6, y - 1, label, MUTED, 8)

    def render_curve(self, s: Surface, points: list[tuple[float, float]], x: int, y: int, w: int, h: int, color=CYAN):
        if len(points) < 2:
            return
        s.rect(x, y, x + w, y + h, outline=DIM)
        last = None
        for px, py in points:
            sx = x + int(px * w)
            sy = y + h - int(py * h)
            if last:
                s.line(last[0], last[1], sx, sy, color)
            last = (sx, sy)

    def render_visual(self, s: Surface, tool: Tool):
        x, y, w, h = 10, 43, 300, 45
        v = tool.value
        if tool.id == "fletcher-munson":
            lift = (100 - v) / 100
            points = [(i / 15, max(0.05, min(0.95, 0.25 + lift * (abs(i - 7.5) / 7.5) ** 1.8))) for i in range(16)]
            self.render_curve(s, points, x, y, w, h, AMBER)
            s.text(x + 4, y + 5, "lows", MUTED, 7)
            s.text(x + w - 35, y + 5, "air", MUTED, 7)
        elif tool.id in ("eq-chart", "voice-eq", "spectrum-analyzer"):
            bands = [(0.08, "SUB"), (0.22, "BASS"), (0.42, "MID"), (0.65, "PRS"), (0.88, "AIR")]
            s.rect(x, y, x + w, y + h, outline=DIM)
            last_x = x
            for ratio, label in bands:
                bx = x + int(ratio * w)
                s.line(bx, y, bx, y + h, DIM)
                s.text(max(last_x + 2, bx - 23), y + h - 13, label, CYAN if label in ("MID", "PRS") else MUTED, 7)
                last_x = bx
            s.line(x, y + h // 2, x + w, y + h // 2, RED)
        elif tool.id == "audio-freq-calc":
            base = max(1, v)
            for i, mult in enumerate((1, 2, 3, 4)):
                bx = x + 12 + i * 64
                bh = int(h * (1 / mult))
                s.rect(bx, y + h - bh, bx + 32, y + h, fill=GREEN if i == 0 else CYAN)
                s.text(bx, y + h + 2, f"{mult}x", MUTED, 7)
            s.text(x + 205, y + 4, fmt_hz(base), TEXT, 8, True)
        elif tool.id == "phase-correlation":
            s.rect(x, y + 16, x + w, y + 29, outline=DIM)
            s.line(x + w // 2, y + 12, x + w // 2, y + 33, DIM)
            pos = x + int((v + 1) / 2 * w)
            s.rect(pos - 4, y + 11, pos + 4, y + 34, fill=RED if v < 0 else GREEN)
            s.text(x, y + 2, "-1", MUTED, 7)
            s.text(x + w // 2 - 4, y + 2, "0", MUTED, 7)
            s.text(x + w - 12, y + 2, "+1", MUTED, 7)
        elif tool.id in ("virtual-piano", "guitar-tuner", "tone-generator", "freq-to-note"):
            midi = int(round(v if tool.id == "virtual-piano" else freq_to_midi(v if tool.id != "guitar-tuner" else [82.41, 110, 146.83, 196, 246.94, 329.63][int(round(v)) % 6])))
            for i in range(14):
                kx = x + i * 20
                active = (midi % 12) == i % 12
                s.rect(kx, y + 5, kx + 17, y + h, fill=RED if active else PANEL, outline=TEXT if active else DIM)
            note = f"{NOTE_NAMES[midi % 12]}{midi // 12 - 1}"
            s.text(x + 230, y + 12, note, GREEN, 14, True)
        elif tool.id == "drum-pads":
            labels = ["KICK", "SNAR", "HAT", "CLAP", "TOM", "RIDE"]
            for i, label in enumerate(labels):
                bx = x + (i % 3) * 72
                by = y + (i // 3) * 22
                s.rect(bx, by, bx + 60, by + 17, outline=RED if i == 0 else DIM)
                s.text(bx + 5, by + 3, label, TEXT, 8, True)
        elif tool.id in ("db-linear", "stereo-width", "lufs-meter", "pitch-shift"):
            if tool.id == "db-linear":
                ratio, label = (v + 80) / 104, f"{v:+.1f}dB"
            elif tool.id == "stereo-width":
                ratio, label = v / 200, f"{v:.0f}%"
            elif tool.id == "lufs-meter":
                ratio, label = (v + 30) / 30, f"{v:.0f} LUFS"
            else:
                ratio, label = (v + 24) / 48, f"{v:+.0f} st"
            self.render_bar(s, x, y + 14, 220, 13, ratio, label)
        elif tool.id in ("tap-tempo", "lfo-rate", "delay-calc", "metronome"):
            bpm = max(1, v)
            beat = (time.monotonic() * bpm / 60.0) % 1.0
            s.rect(x, y + 17, x + w, y + 29, outline=DIM)
            s.rect(x + 2, y + 19, x + int(beat * (w - 4)), y + 27, fill=GREEN)
            s.text(x + 230, y + 2, f"{bpm:.1f} BPM", TEXT, 9, True)
        elif tool.id == "circle-of-fifths":
            cx, cy = x + 147, y + 22
            selected = int(round(v)) % 12
            for i, key in enumerate(MAJOR_KEYS):
                ang = -math.pi / 2 + i * math.tau / 12
                px = cx + int(math.cos(ang) * 85)
                py = cy + int(math.sin(ang) * 20)
                s.text(px, py, key, RED if i == selected else MUTED, 8, i == selected, anchor="n")

    def render(self):
        s = Surface()
        self.shell(s, "TOOLKIT")
        if self.mode == "categories":
            s.text(8, 28, "NOIRSONANCE TOOLKIT", RED, 11, True)
            for i, (_, label) in enumerate(self.categories):
                count = len([t for t in self.tools if t.category == self.categories[i][0]])
                x = 10 + (i % 2) * 154
                y = 51 + (i // 2) * 25
                if i == self.category_index:
                    s.rect(x - 3, y - 3, x + 138, y + 19, outline=RED)
                    s.text(x - 9, y, ">", RED, 9, True)
                s.text(x, y, f"[{i + 1}] {label[:14]}", TEXT, 9, True)
                s.text(x, y + 11, f"{count} tools", MUTED, 8)
            s.text(8, 139, f"{len(self.tools)} compact audio tools onboard.", CYAN, 8)
            s.text(8, 151, "Arrows select   ENTER open   Q quit", MUTED, 8)
            return s
        if self.mode == "list":
            tools = self.category_tools()
            pages = max(1, math.ceil(len(tools) / 5))
            _, label = self.categories[self.category_index]
            s.text(8, 28, label.upper(), RED, 10, True)
            s.text(310, 28, f"{self.list_page + 1}/{pages}", MUTED, 9, anchor="ne")
            for slot, tool in enumerate(tools[self.list_page * 5 : self.list_page * 5 + 5]):
                absolute = self.list_page * 5 + slot
                y = 47 + slot * 21
                if absolute == self.tool_index:
                    s.rect(6, y - 3, 313, y + 18, outline=RED)
                    s.text(10, y, ">", RED, 9, True)
                    tx = 20
                else:
                    tx = 10
                s.text(tx, y, f"[{slot + 1}] {tool.name}", TEXT, 9, True)
                s.text(tx + 14, y + 10, tool.desc[:41], MUTED, 8)
            s.text(8, 151, "UP/DOWN select ENTER open LEFT/RIGHT page", MUTED, 8)
            return s
        tool = self.current_tool()
        s.text(8, 27, tool.name.upper()[:28], RED, 10, True)
        s.text(310, 27, tool.category.upper()[:10], MUTED, 8, anchor="ne")
        if self.has_visual(tool):
            self.render_visual(s, tool)
            text_y = 94
            max_lines = 3
        else:
            text_y = 45
            max_lines = 6
        for row, line in enumerate(self.tool_lines(tool)[:max_lines]):
            color = GREEN if row == 1 else TEXT
            s.text(10, text_y + row * 16, line, color, 9, row == 1)
        if tool.id in {"lufs-meter", "stereo-width", "phase-correlation", "spectrum-analyzer", "file-size"}:
            hint = "L load WAV   LEFT/RIGHT adjust   ESC list"
        elif tool.id in ("tap-tempo", "melody-generator"):
            hint = "SPACE tap/regenerate   ESC list"
        else:
            hint = "LEFT/RIGHT adjust   ESC list"
        if tool.step == 0:
            hint = "ESC list"
        s.text(8, 151, hint, MUTED, 8)
        return s


if __name__ == "__main__":
    raise SystemExit(run_app(NoirToolkit))
